const rp = require('request-promise');
const cheerio = require('cheerio');
const db = require('../AWS_Helpers');
//const resorts = require("../TestStuff/index");
const fs = require('fs');

var dir = './WebScraper/resorts';
function readFiles(dir, callback) {
    let fileNameList = [];

    fs.readdir(dir, function (err, resortList) {
        console.log("Reading resorts from directory: " + dir);

        if (err) {
            console.log("ERROR " + err);
        }
        else {
            console.log("Fetching data from files");
            for (var i = 0; i < resortList.length; i++) {
                var filename = resortList[i];
                fileNameList.push(filename);

                fs.readFile(dir + "/" + filename, function (err, data) {
                    if (err) {
                        console.log("ERROR in reading file w/ msg: " + err);
                    }
                    else {
                        var parsedData = JSON.parse(data);
                        //console.log(parsedData);
                        console.log("resort name : " + parsedData.name);

                    }
                });
            }

            console.log("list of files: " + fileNameList);
            callback(fileNameList);
        }
    });
}

readFiles(dir, (callback) => {
    console.log("the callback was: " + callback);
    fs.readFile(dir + "/" + callback[1], function(err, data) {
        console.log("DATA: " +data);
    })
})





//console.log(resorts.stevens.name);
//TODO: make json of each resort
//TODO: require in the index file and then grab from here
//TODO: loop through each json file which will have the same structure and then store to the db
//example: https://stackoverflow.com/questions/5364928/node-js-require-all-files-in-a-folder

//--------------CALL LAMBDA TEST TO RUN exports.handler--------------------
//TODO: Scraper file for each site to scrape?
//TODO: Add additional for lifts
//TODO: Will probably just report num lifts open / total instead of specific ones
//TODO: COuld report frontside/backside lifts or output to the card which lifts are clsoed/open

//
// exports.handler = function(event, context, callback) {
//     //Gets response of all data scraped
//     //Puts the data into table
//     scrapeSite((data) => {
//         if (data === "ERROR") {
//             //TODO: Handle error msg
//             console.log("Error occurred in scraping Stevens Pass website");
//         } else {
//             var params = {
//                 TableName: "SkiResortData",
//                 Item: {
//                     "resort": "Stevens Pass",
//                     "overNightSnowFall": data.overNightSnowFall,
//                     "snowFallOneDay": data.snowFallOneDay,
//                     "snowFallTwoDay": data.snowFallTwoDay,
//                     "snowDepthBase": data.snowDepthBase,
//                     "snowDepthMidMtn": data.snowDepthMidMtn,
//                     "seasonSnowFall": data.seasonSnowFall
//                 }
//             };
//
//             //Push this data to the database
//             console.log("Adding data to database...");
//             db.putData(params, (response) => {
//                 if (response == "FAILED") {
//                     console.log("DB Error: Unable to add " + params.Item.resort);
//                 }
//                 else {
//                     console.log("Data push successful");
//                 }
//             });
//         }
//     });
// }
//
// function pushToDB(params) {
//
//     console.log("Adding data to database...");
//     db.putData(params, (response) => {
//         if (response == "FAILED") {
//             console.log("DB Error: Unable to add " + params.Item.resort);
//         }
//         else {
//             console.log("Data push successful");
//         }
//     });
// }
//
// function scrapeSite(callback) {
//     const options = {
//         uri: 'https://www.stevenspass.com/site/mountain/reports/snow-and-weather-report/@@snow-and-weather-report',
//         transform: function (body) {
//             return cheerio.load(body);
//         }
//     };
//
//     console.log("Fetching data from site...");
//     rp(options)
//         .then(($) => {
//             console.log("Data received");
//             var reportDateUpdated = $('.page-report-snowfall-value');
//             var snowFallTotals = $('.page-report-snowfall-value');
//             var snowDepthTotals = $('.page-report-snowdepth-value');
//
//             var data = {
//                 reportDateUpdated: $(reportDateUpdated).text(),
//                 overNightSnowFall: $(snowFallTotals[0]).text().slice(0, -1),
//                 snowFallOneDay: $(snowFallTotals[1]).text().slice(0, -1),
//                 snowFallTwoDay: $(snowFallTotals[2]).text().slice(0, -1),
//                 snowDepthBase: $(snowDepthTotals[0]).text().slice(0, -1),
//                 snowDepthMidMtn: $(snowDepthTotals[1]).text().slice(0, -1),
//                 seasonSnowFall: $(snowDepthTotals[2]).text().slice(0, -1)
//             };
//             callback(data);
//         })
//         .catch((err) => {
//             console.log(err);
//             callback("ERROR");
//         });
// };